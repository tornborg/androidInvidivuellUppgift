package com.example.induppgift;


import android.app.Activity;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.widget.TextView;

public class accelActivity extends Activity implements SensorEventListener {
    private TextView xOut, yOut, zOut;
    private String xString, yString, zString;
    private Sensor accel;
    private SensorManager sManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accel);

        sManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        accel = (Sensor) sManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);

        xOut = (TextView) findViewById(R.id.xText);
        yOut = (TextView) findViewById(R.id.yText);
        zOut = (TextView) findViewById(R.id.zText);
    }

    @Override
    protected void onPause(){
        super.onPause();
        sManager.unregisterListener(this);

    }

    @Override
    protected void onResume() {
        super.onResume();
        sManager.registerListener(this, sManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        synchronized (this) {
            xString = String.format("X: %.3f", event.values[0]);
            xOut.setText(xString);
            yString = String.format("Y: %.3f", event.values[1]);
            yOut.setText(yString);
            zString = String.format("Z: %.3f", event.values[2]);
            zOut.setText(zString);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
